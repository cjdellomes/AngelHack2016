**** DELETE THIS BLOCK ****

Thanks for filing an issue!  Please keep keep issues limited to bug reports, feature requests, and other general issues. For support questions, please feel free to reach out on stack overflow: http://stackoverflow.com/questions/tagged/google-api-nodejs-client

**** /DELETE THIS BLOCK ****

<your detailed question and code samples go here>

Thanks!
